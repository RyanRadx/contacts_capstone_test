package com.capstonetest.contacts;

import org.bouncycastle.asn1.pkcs.PrivateKeyInfo;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openssl.PEMParser;
import org.bouncycastle.openssl.jcajce.JcaPEMKeyConverter;
import org.bouncycastle.openssl.jcajce.JceOpenSSLPKCS8DecryptorProviderBuilder;
import org.bouncycastle.operator.InputDecryptorProvider;
import org.bouncycastle.pkcs.PKCS8EncryptedPrivateKeyInfo;

import java.io.FileReader;
import java.nio.file.Paths;
import java.security.PrivateKey;
import java.security.Security;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.DriverManager;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class ContactsDBUtil {
    //Constructor
    public ContactsDBUtil() {
    }

    // Path to the private key file that you generated earlier.
    private static final String PRIVATE_KEY_FILE = "C:/Users/f9w0ld8/OneDrive - Fiserv Corp/Desktop/dev_snowflake_training_rsa_key.p8";

    public static class PrivateKeyReader
    {

        // If you generated an encrypted private key, implement this method to return
        // the passphrase for decrypting your private key.
        private static String getPrivateKeyPassphrase() {
            return "B7GX$en3Pz#fSw8yi!pv";
        }

        public static PrivateKey get(String filename)
                throws Exception
        {
            PrivateKeyInfo privateKeyInfo = null;
            Security.addProvider(new BouncyCastleProvider());
            // Read an object from the private key file.
            PEMParser pemParser = new PEMParser(new FileReader(Paths.get(filename).toFile()));
            Object pemObject = pemParser.readObject();
            if (pemObject instanceof PKCS8EncryptedPrivateKeyInfo) {
                // Handle the case where the private key is encrypted.
                PKCS8EncryptedPrivateKeyInfo encryptedPrivateKeyInfo = (PKCS8EncryptedPrivateKeyInfo) pemObject;
                String passphrase = getPrivateKeyPassphrase();
                InputDecryptorProvider pkcs8Prov = new JceOpenSSLPKCS8DecryptorProviderBuilder().build(passphrase.toCharArray());
                privateKeyInfo = encryptedPrivateKeyInfo.decryptPrivateKeyInfo(pkcs8Prov);
            } else if (pemObject instanceof PrivateKeyInfo) {
                // Handle the case where the private key is unencrypted.
                privateKeyInfo = (PrivateKeyInfo) pemObject;
            }
            pemParser.close();
            JcaPEMKeyConverter converter = new JcaPEMKeyConverter().setProvider(BouncyCastleProvider.PROVIDER_NAME);
            return converter.getPrivateKey(privateKeyInfo);
        }
    }

    public List<Contacts> getContacts() throws Exception {
        //Connection Parameters
        String url = "jdbc:snowflake://fiservbanksolutionsawslow1.us-east-1.privatelink.snowflakecomputing.com/";
        Properties prop = new Properties();
        prop.put("user", "dev_snowflake_training_svc");
        prop.put("privateKey", PrivateKeyReader.get(PRIVATE_KEY_FILE));
        prop.put("db", "TECHNICAL_TRAINEE");
        prop.put("schema", "RRADWANSKI");
        prop.put("warehouse", "DEV_TECHNICAL_TRAINEE_WH");
        prop.put("role", "FR_DEV_TECHNICAL_TRAINEE_SERVICE");

        //Establish Connection
        Connection conn = DriverManager.getConnection(url, prop);
        Statement stat = conn.createStatement();

        //Alter session format to return JSON formatted data
        stat.executeQuery("ALTER SESSION SET JDBC_QUERY_RESULT_FORMAT='JSON'");

        //Query Execution
        ResultSet res = stat.executeQuery("SELECT * FROM CONTACTS");

        //Processing of Result Set
        List<Contacts> contacts = new ArrayList<>();

        while (res.next()) {
            //Get data from result set row
            int iD = res.getInt("CONTACTS_ID");
            String fName = res.getString("CONTACTS_FNAME");
            String lName = res.getString("CONTACTS_LNAME");
            long telephone = res.getLong("CONTACTS_TELEPHONE");
            String eMail = res.getString("EMAIL");

            //create new contact object
            Contacts tempContact = new Contacts(iD, fName, lName, telephone, eMail);

            //add contact object to list of contacts
            contacts.add(tempContact);
//            System.out.println(contacts.toString());
        };

//        System.out.println(res.getString(1)+" "+res.getString(2)+" "+res.getString(3));
//        res.next();
//        System.out.println(res.getString(1)+" "+res.getString(2)+" "+res.getString(3));

        //Closing the Database Connection
        conn.close();

        return contacts;
    }
}
