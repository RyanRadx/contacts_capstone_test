package com.capstonetest.contacts;

import java.util.List;

public class test {
    public static void main(String[] args){
        List<Contacts> contacts;

        {
            try {
                contacts = new ContactsDBUtil().getContacts();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }

    }

}
