package com.capstonetest.contacts;

public class Contacts {
    int iD;
    String fName;
    String lName;
    long telephone;
    String eMail;

    public Contacts(int iD, String fName, String lName, long telephone, String eMail) {
        this.iD = iD;
        this.fName = fName;
        this.lName = lName;
        this.telephone = telephone;
        this.eMail = eMail;
    }

    public Contacts() {
    }

    public int getiD() {
        return iD;
    }

    public void setiD(int iD) {
        this.iD = iD;
    }

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getlName() {
        return lName;
    }

    public void setlName(String lName) {
        this.lName = lName;
    }

    public long getTelephone() {
        return telephone;
    }

    public void setTelephone(long telephone) {
        this.telephone = telephone;
    }

    public String geteMail() {
        return eMail;
    }

    public void seteMail(String eMail) {
        this.eMail = eMail;
    }
}
