package com.capstonetest.contacts;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
public class ContactsController {
    @CrossOrigin(origins = {"http://localhost:3000"})
    @GetMapping ("/contacts")
    public List<Contacts> getContacts() {
        List<Contacts> contacts;
            try {
                contacts = new ContactsDBUtil().getContacts();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
    return contacts;
    }

    @GetMapping("/hello-world")
    public String helloWorld(){
        return "Hello-World";
    }
}